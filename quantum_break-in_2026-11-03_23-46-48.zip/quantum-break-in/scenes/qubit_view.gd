class_name QubitView
extends Control
## Draws one qubit and reports clicks.
##   disc brightness = chance of measuring 1
##   ring color      = relative phase (only shown for superpositions)
##   magenta ring    = entangled with another qubit
## Sentinel eyes are added as children above the disc.

signal clicked(index: int)

const VIEW_SIZE := Vector2(160, 280)
const DISC_CENTER := Vector2(80, 150)
const DISC_RADIUS := 48.0

var index := 0
var selected := false:
	set(value):
		selected = value
		queue_redraw()

var p1 := 0.0
var coherence := 0.0
var phase := 0.0
var pure := true
var sentinel_views: Array[SentinelView] = []


func _init() -> void:
	custom_minimum_size = VIEW_SIZE
	size_flags_vertical = Control.SIZE_SHRINK_CENTER
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND


## `info` from QuantumSim.qubit_info().
func show_info(info: Dictionary) -> void:
	p1 = info["p1"]
	coherence = info["coherence"]
	phase = info["phase"]
	pure = info["pure"]
	queue_redraw()


func add_sentinel(eye: SentinelView) -> void:
	sentinel_views.append(eye)
	add_child(eye)
	var total_width := SentinelView.EYE_SIZE.x * sentinel_views.size()
	var x := (VIEW_SIZE.x - total_width) / 2.0
	for e in sentinel_views:
		e.position = Vector2(x, 0.0)
		x += SentinelView.EYE_SIZE.x


## Short color flash, used when a sentinel looks at this qubit.
func flash(color: Color) -> void:
	modulate = color
	create_tween().tween_property(self, "modulate", Color.WHITE, 2.0)


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		clicked.emit(index)


func _draw() -> void:
	var font := ThemeDB.fallback_font
	if selected:
		draw_rect(Rect2(Vector2.ZERO, VIEW_SIZE), Color(1, 1, 1, 0.07), true)
		draw_rect(Rect2(Vector2.ZERO, VIEW_SIZE), Color(1, 1, 1, 0.5), false, 2.0)

	var ring_color := Color(0.55, 0.6, 0.7)
	var bright_color := Color(0.8, 0.9, 1.0)
	if coherence > 0.05:
		ring_color = Color.from_hsv(fposmod(phase / TAU, 1.0), 0.75, 1.0)
		bright_color = ring_color

	draw_circle(DISC_CENTER, DISC_RADIUS, Color(0.1, 0.11, 0.16).lerp(bright_color, p1))
	draw_arc(DISC_CENTER, DISC_RADIUS, 0.0, TAU, 64, ring_color, 4.0, true)
	if not pure:
		draw_arc(DISC_CENTER, DISC_RADIUS + 9.0, 0.0, TAU, 64, Color(0.9, 0.35, 0.95), 3.0, true)

	draw_string(font, Vector2(0, 232), "q%d" % index, HORIZONTAL_ALIGNMENT_CENTER, VIEW_SIZE.x, 22)
	draw_string(font, Vector2(0, 252), "P(1) = %d%%" % roundi(p1 * 100.0),
		HORIZONTAL_ALIGNMENT_CENTER, VIEW_SIZE.x, 14, Color(0.8, 0.8, 0.85))
	if not pure:
		draw_string(font, Vector2(0, 270), "entangled",
			HORIZONTAL_ALIGNMENT_CENTER, VIEW_SIZE.x, 13, Color(0.9, 0.35, 0.95))
