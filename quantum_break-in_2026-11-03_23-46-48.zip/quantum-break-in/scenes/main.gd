extends Control

## One turn:  gate button -> sim.apply_gate() -> _resolve_step() -> _refresh()

const QUBIT_VIEW_SCENE := preload("res://scenes/qubit_view.tscn")
const SENTINEL_VIEW_SCENE := preload("res://scenes/sentinel_view.tscn")
const WIN_THRESHOLD := 0.999  # chance of the password needed to count as a match

enum State { PLAYING, WON, LOST, PAUSE }

@onready var level_label: Label = %LevelLabel
@onready var hint_label: Label = %HintLabel
@onready var info_label: Label = %InfoLabel
@onready var qubit_row: HBoxContainer = %QubitRow
@onready var message_label: Label = %MessageLabel
@onready var gate_row: HBoxContainer = %GateRow
@onready var restart_button: Button = %RestartButton
@onready var next_button: Button = %NextButton

var level_index := 0
var level: Dictionary = {}
var sim: QuantumSim
var qubit_views: Array[QubitView] = []
var sentinels: Array[Dictionary] = []  # each entry: {view, qubit, every}
var selected := 0
var steps_used := 0
var state := State.PLAYING
var target_index := 0


func _ready() -> void:
	restart_button.pressed.connect(func(): load_level(level_index))
	next_button.pressed.connect(func(): load_level(level_index + 1))
	load_level(4)


# ---------------------------------------------------------------- level setup

func load_level(i: int) -> void:
	level_index = i % LevelData.LEVELS.size()
	level = LevelData.LEVELS[level_index]
	state = State.PLAYING
	steps_used = 0
	selected = 0
	target_index = QuantumSim.password_to_index(level["target"])

	sim = QuantumSim.new(level["qubits"])
	for prep_step in level["prep"]:
		sim.apply_gate(prep_step[0], prep_step[1])

	# Remove the previous level's nodes.
	for child in qubit_row.get_children():
		child.queue_free()
	for child in gate_row.get_children():
		child.queue_free()
	qubit_views.clear()
	sentinels.clear()

	# One QubitView scene instance per qubit.
	for q in int(level["qubits"]):
		var view := QUBIT_VIEW_SCENE.instantiate() as QubitView
		view.index = q
		view.clicked.connect(_on_qubit_clicked)
		qubit_row.add_child(view)
		qubit_views.append(view)

	# One SentinelView per sentinel, attached to the qubit it watches.
	for s in level["sentinels"]:
		var eye := SENTINEL_VIEW_SCENE.instantiate() as SentinelView
		qubit_views[s["qubit"]].add_sentinel(eye)
		sentinels.append({"view": eye, "qubit": s["qubit"], "every": s["every"], "start": s["start"]})

	# Gate buttons come from the level's allowed-gate list.
	for gate in level["gates"]:
		if gate == "CNOT":
			for a in range(sim.n - 1):
				_add_gate_button("CNOT %d->%d" % [a, a + 1], "CNOT", [a, a + 1])
				_add_gate_button("CNOT %d->%d" % [a + 1, a], "CNOT", [a + 1, a])
		elif gate.begins_with("CNOT"):
			var a: PackedStringArray = gate.split(" ")[1].split("->")
			var cq := int(a[0])
			var tq := int(a[1])
			if cq >= 0 and cq < sim.n and tq >= 0 and tq < sim.n and cq != tq:
				_add_gate_button(gate, "CNOT", [cq, tq])
			else:
				push_error("Qubit out of range: " + gate)
		else:
			_add_gate_button(gate, gate, [])  # [] = "use the selected qubit"

	_set_message("Click a qubit to select it, then press a gate.", Color(0.8, 0.9, 1.0))
	_refresh()


func _add_gate_button(label: String, gate: String, fixed_targets: Array) -> void:
	var button := Button.new()
	button.text = label
	button.custom_minimum_size = Vector2(96, 48)
	button.pressed.connect(_on_gate_pressed.bind(gate, fixed_targets))
	gate_row.add_child(button)


# ---------------------------------------------------------------- input

func _on_qubit_clicked(index: int) -> void:
	selected = index
	_refresh()


func _on_gate_pressed(gate: String, fixed_targets: Array) -> void:
	if state != State.PLAYING:
		return
	var targets: Array = fixed_targets if not fixed_targets.is_empty() else [selected]
	sim.apply_gate(gate, targets)
	steps_used += 1
	_resolve_step()


# ---------------------------------------------------------------- rules

func _reached_target() -> bool:
	return sim.prob_basis(target_index) > WIN_THRESHOLD


func _resolve_step() -> void:
	# 1. Password reached: the hack succeeds before any sentinel looks.
	if _reached_target():
		_finish(State.WON, "ACCESS GRANTED - password matched", Color(0.4, 1.0, 0.5))
		return
		
	# 1.5. Wait a bit
	state = State.PAUSE
	_refresh()
	await get_tree().create_timer(0.75).timeout
	state = State.PLAYING

	# 2. Sentinels that are due measure their qubit.
	var report := ""
	for s in sentinels:
		var every: int = s["every"]
		var start: int = s["start"]
		if (steps_used - start) % every != 0:
			continue
		var q: int = s["qubit"]
		var chance_caught := sim.prob_one(q)
		var outcome := sim.measure(q)  # collapses the state (and anything entangled with q)
		if outcome == 1:
			qubit_views[q].flash(Color(1.0, 0.3, 0.3))
			_finish(State.LOST, "DETECTED - the sentinel measured qubit %d as 1" % q, Color(1.0, 0.4, 0.4))
			return
		qubit_views[q].flash(Color(0.5, 1.0, 0.6))
		if chance_caught > 0.001:
			report += "Lucky! The sentinel had a %d%% chance to catch qubit %d but saw 0 and collapsed it.  " % [roundi(chance_caught * 100.0), q]
		else:
			report += "The sentinel looked at qubit %d and saw 0.  " % q

	# 3. A collapse can itself land on the password.
	if _reached_target():
		_finish(State.WON, report + "ACCESS GRANTED", Color(0.4, 1.0, 0.5))
		return

	# 4. Out of steps?
	if steps_used >= int(level["steps"]):
		_finish(State.LOST, report + "OUT OF STEPS", Color(1.0, 0.4, 0.4))
		return

	_set_message(report, Color(0.8, 0.9, 1.0))
	_refresh()


func _finish(new_state: State, text: String, color: Color) -> void:
	state = new_state
	_set_message(text, color)
	_refresh()


# ---------------------------------------------------------------- display

func _set_message(text: String, color: Color) -> void:
	message_label.text = text
	message_label.modulate = color


func _refresh() -> void:
	level_label.text = "Level %d / %d: %s" % [level_index + 1, LevelData.LEVELS.size(), level["name"]]
	hint_label.text = level["hint"]
	info_label.text = "Target password: %s     Steps: %d / %d" % [
		level["target"], steps_used, level["steps"]]

	for q in qubit_views.size():
		qubit_views[q].show_info(sim.qubit_info(q))
		qubit_views[q].selected = (q == selected)

	for s in sentinels:
		var eye := s["view"] as SentinelView
		var every: int = s["every"]
		var start: int = s["start"]
		eye.risk = sim.prob_one(s["qubit"])
		eye.next_check = (floori(float(steps_used - start) / every) + 1) * every + start

	for child in gate_row.get_children():
		if child is Button:
			child.disabled = (state != State.PLAYING)

	next_button.visible = (state == State.WON)
	next_button.text = "Next level" if level_index < LevelData.LEVELS.size() - 1 else "Play again"
