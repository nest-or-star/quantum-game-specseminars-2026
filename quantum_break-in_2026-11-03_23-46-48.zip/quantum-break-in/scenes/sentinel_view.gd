class_name SentinelView
extends Control
## An eye that is drawn above the qubit it watches. The iris turns red as the
## chance of being detected (P(1) of the watched qubit) goes up.

const EYE_SIZE := Vector2(70, 80)

var risk := 0.0:
	set(value):
		risk = value
		queue_redraw()
var next_check := 1:
	set(value):
		next_check = value
		queue_redraw()


func _init() -> void:
	custom_minimum_size = EYE_SIZE
	mouse_filter = Control.MOUSE_FILTER_IGNORE  # clicks fall through to the QubitView


func _draw() -> void:
	var center := Vector2(EYE_SIZE.x / 2.0, 28.0)
	var outline := PackedVector2Array()
	for i in 32:
		var a := TAU * i / 32.0
		outline.append(center + Vector2(cos(a) * 30.0, sin(a) * 16.0))
	draw_colored_polygon(outline, Color(0.95, 0.95, 0.95))
	outline.append(outline[0])
	draw_polyline(outline, Color(0.05, 0.05, 0.08), 2.0, true)

	var iris := Color(0.2, 0.85, 0.35).lerp(Color(0.95, 0.15, 0.15), risk)
	draw_circle(center, 13.0, iris)
	draw_circle(center, 6.0, Color(0.02, 0.02, 0.04))

	draw_string(ThemeDB.fallback_font, Vector2(0, 66), "step %d" % next_check,
		HORIZONTAL_ALIGNMENT_CENTER, EYE_SIZE.x, 11, Color(0.8, 0.8, 0.85))
