class_name LevelData
extends RefCounted
## Levels are plain dictionaries: adding a level means adding one entry, no scene changes.
##
## name / hint : text shown on screen
## qubits      : number of qubits (all start in |0>)
## prep        : free gates applied before the player starts: [gate, [targets]]
## target      : password; character i is the wanted value of qubit i
## gates       : gates the player may use. "CNOT" creates a button for every adjacent pair.
## steps       : maximum number of gate applications
## sentinels   : [{"qubit": q, "every": n}] - after every n-th step the eye measures qubit q.
##               Measuring 1 = detected (game over). Measuring 0 = the qubit collapses to 0.
##
## Rule order each turn: password reached? -> win.  Otherwise sentinels measure.  Otherwise out of steps? -> lose.

const LEVELS := [
	{
		"name": "Bit Flip",
		"hint": "Warm-up: make the password 1. Click a qubit to select it, then press a gate.",
		"qubits": 1,
		"prep": [],
		"target": "1",
		"gates": ["X"],
		"steps": 1,
		"sentinels": [],
	},
	{
		"name": "Interference",
		"hint": "There is no X gate here. Try putting Z between two H gates, and watch the ring color.",
		"qubits": 1,
		"prep": [],
		"target": "1",
		"gates": ["H", "Z"],
		"steps": 3,
		"sentinels": [],
	},
	{
		"name": "Guard Duty",
		"hint": "The eye measures qubit 1 after every step. Seeing a 1 ends your run. Reaching the password first ends the hack before the eye looks.",
		"qubits": 2,
		"prep": [],
		"target": "11",
		"gates": ["X", "CNOT"],
		"steps": 2,
		"sentinels": [{"qubit": 1, "start": 0, "every": 1}],
	},
	{
		"name": "Untangle",
		"hint": "The qubits start entangled (magenta ring). Undo the entanglement. One first move is safe, the other is a gamble.",
		"qubits": 2,
		"prep": [["H", [0]], ["CNOT", [0, 1]]],
		"target": "00",
		"gates": ["H", "CNOT"],
		"steps": 2,
		"sentinels": [{"qubit": 1, "start": 0, "every": 1}],
	},
	{
		"name": "Triplet",
		"hint": "Notice how the sentinel skips every other turn.",
		"qubits": 3,
		"prep": [],
		"target": "111",
		"gates": ["H", "Z", "CNOT 0->1", "CNOT 1->2"],
		"steps": 5,
		"sentinels": [{"qubit": 1, "start": 1, "every": 2}],
	},
	{
		"name": "Two Locks",
		"hint": "No X gate, and three eyes with exact timing.",
		"qubits": 4,
		"prep": [],
		"target": "1101",
		"gates": ["H", "Z", "CNOT 0->1", "CNOT 2->3"],
		"steps": 7,
		"sentinels": [
			{"qubit": 1, "start": 3, "every": 99},
			{"qubit": 3, "start": 4, "every": 99},
			{"qubit": 2, "start": 5, "every": 99},
		],
	},
]
