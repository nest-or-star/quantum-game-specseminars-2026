@tool
extends EditorScript
## Test file to make sure quantum sim works as intented

## Open this file in the Script editor, then File > Run (Ctrl+Shift+X).
## The results appear in the Output panel at the bottom.

var failures := 0


func _run() -> void:
	failures = 0

	var s := QuantumSim.new(1)
	s.apply_gate("H", [0])
	s.apply_gate("H", [0])
	_check("H then H returns to |0>", _near(s.prob_one(0), 0.0))

	s = QuantumSim.new(1)
	for g in ["H", "Z", "H"]:
		s.apply_gate(g, [0])
	_check("H, Z, H turns |0> into |1> (interference)", _near(s.prob_one(0), 1.0))

	s = QuantumSim.new(1)
	s.apply_gate("H", [0])
	var plus: Dictionary = s.qubit_info(0)
	s.apply_gate("Z", [0])
	var minus: Dictionary = s.qubit_info(0)
	_check("Z changes the phase of |+> by pi", _near(absf(minus["phase"] - plus["phase"]), PI))

	s = QuantumSim.new(2)
	s.apply_gate("H", [0])
	s.apply_gate("CNOT", [0, 1])
	_check("Bell state is 50% |00> and 50% |11>", _near(s.prob_basis(0), 0.5) and _near(s.prob_basis(3), 0.5))
	var info: Dictionary = s.qubit_info(0)
	_check("Bell state: qubit 0 is reported as entangled", not info["pure"])
	var outcome := s.measure(0)
	_check("Measuring one half of a Bell pair fixes the other", _near(s.prob_one(1), float(outcome)))

	s = QuantumSim.new(2)
	for step in [["H", [0]], ["CNOT", [0, 1]], ["CNOT", [0, 1]], ["H", [0]]]:
		s.apply_gate(step[0], step[1])
	_check("Level 4: Bell pair, then CNOT, then H returns to |00>", _near(s.prob_basis(0), 1.0))

	_check("password_to_index('101') == 5", QuantumSim.password_to_index("101") == 5)

	if failures == 0:
		print("---- ALL TESTS PASSED ----")
	else:
		print("---- %d TEST(S) FAILED ----" % failures)


func _check(label: String, ok: bool) -> void:
	if not ok:
		failures += 1
	print(("PASS  " if ok else "FAIL  ") + label)


func _near(a: float, b: float) -> bool:
	return absf(a - b) < 1e-6
