@tool
class_name QuantumSim
extends RefCounted
## Conventions
##  - Qubit i is bit i of the basis-state index, so qubit 0 is the least significant bit.
##  - A password string such as "101" means q0=1, q1=0, q2=1 (read left to right).
##  - Amplitudes are stored in two arrays: amplitude[k] = re[k] + i * im[k].

## 1 / sqrt(2)
const INV_SQRT2 := 0.7071067811865476

## One-qubit gates as a 2x2 matrix [[a, b], [c, d]], each entry written as (real, imag):
##   new0 = a * old0 + b * old1
##   new1 = c * old0 + d * old1
const GATES := {
	"H": [INV_SQRT2, 0.0, INV_SQRT2, 0.0, INV_SQRT2, 0.0, -INV_SQRT2, 0.0],
	"X": [0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0],
	"Y": [0.0, 0.0, 0.0, -1.0, 0.0, 1.0, 0.0, 0.0],
	"Z": [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0],
	"S": [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
	"T": [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, INV_SQRT2, INV_SQRT2],
}

var n: int = 1
var dim: int = 2
var re := PackedFloat64Array()
var im := PackedFloat64Array()
var rng := RandomNumberGenerator.new()


func _init(num_qubits: int = 1) -> void:
	n = num_qubits
	dim = 1 << n
	rng.randomize()
	reset()


## |00...0>
func reset() -> void:
	re.resize(dim)
	im.resize(dim)
	re.fill(0.0)
	im.fill(0.0)
	re[0] = 1.0


## "101" -> basis index (q0=1, q1=0, q2=1).
static func password_to_index(password: String) -> int:
	var index := 0
	for i in password.length():
		if password[i] == "1":
			index |= 1 << i
	return index


## Applies a gate. `targets` is [qubit] for one-qubit gates and [control, target] for CNOT.
func apply_gate(gate: String, targets: Array) -> void:
	if gate == "CNOT":
		_apply_cnot(targets[0], targets[1])
	elif GATES.has(gate):
		_apply_1q(targets[0], GATES[gate])
	else:
		push_error("Unknown gate: " + gate)


func _apply_1q(q: int, m: Array) -> void:
	var ar: float = m[0]
	var ai: float = m[1]
	var br: float = m[2]
	var bi: float = m[3]
	var cr: float = m[4]
	var ci: float = m[5]
	var dr: float = m[6]
	var di: float = m[7]
	var bit := 1 << q
	for k in dim:
		if (k & bit) != 0:
			continue
		var k1 := k | bit
		var x0r := re[k]
		var x0i := im[k]
		var x1r := re[k1]
		var x1i := im[k1]
		re[k] = ar * x0r - ai * x0i + br * x1r - bi * x1i
		im[k] = ar * x0i + ai * x0r + br * x1i + bi * x1r
		re[k1] = cr * x0r - ci * x0i + dr * x1r - di * x1i
		im[k1] = cr * x0i + ci * x0r + dr * x1i + di * x1r


## Flips the target qubit on every basis state where the control qubit is 1.
func _apply_cnot(control: int, target: int) -> void:
	var cbit := 1 << control
	var tbit := 1 << target
	for k in dim:
		if (k & cbit) != 0 and (k & tbit) == 0:
			var k1 := k | tbit
			var tmp_r := re[k]
			var tmp_i := im[k]
			re[k] = re[k1]
			im[k] = im[k1]
			re[k1] = tmp_r
			im[k1] = tmp_i


## Probability that measuring qubit q gives 1.
func prob_one(q: int) -> float:
	var bit := 1 << q
	var p := 0.0
	for k in dim:
		if (k & bit) != 0:
			p += re[k] * re[k] + im[k] * im[k]
	return p


## Probability of one exact basis state (e.g. the target password).
func prob_basis(index: int) -> float:
	return re[index] * re[index] + im[index] * im[index]


## What a single qubit "looks like" (used for drawing).
## p1: chance of 1.  coherence: 0 = definite 0/1, up to 0.5 = full superposition.
## phase: relative phase between |1> and |0> (only meaningful if coherence > 0).
## pure: false if the qubit is entangled with others.
func qubit_info(q: int) -> Dictionary:
	var bit := 1 << q
	var p0 := 0.0
	var p1 := 0.0
	var cr := 0.0
	var ci := 0.0
	for k in dim:
		if (k & bit) != 0:
			continue
		var k1 := k | bit
		p0 += re[k] * re[k] + im[k] * im[k]
		p1 += re[k1] * re[k1] + im[k1] * im[k1]
		# rho01 = sum of a0 * conj(a1)
		cr += re[k] * re[k1] + im[k] * im[k1]
		ci += im[k] * re[k1] - re[k] * im[k1]
	var coherence := sqrt(cr * cr + ci * ci)
	var purity := p0 * p0 + p1 * p1 + 2.0 * coherence * coherence
	return {
		"p1": p1,
		"coherence": coherence,
		"phase": atan2(-ci, cr),
		"pure": purity > 0.999,
	}


## Measures qubit q: picks 0 or 1 with the Born rule, collapses the state, returns the result.
func measure(q: int) -> int:
	var p1 := prob_one(q)
	var outcome := 0
	if p1 > 1.0 - 1e-9:
		outcome = 1
	elif p1 > 1e-9 and rng.randf() < p1:
		outcome = 1
	collapse(q, outcome)
	return outcome


## Forces qubit q to `outcome`, zeroing the other half of the state and renormalizing.
## Entangled qubits are affected too.
func collapse(q: int, outcome: int) -> void:
	var bit := 1 << q
	var norm := 0.0
	for k in dim:
		var has_bit := (k & bit) != 0
		if has_bit != (outcome == 1):
			re[k] = 0.0
			im[k] = 0.0
		else:
			norm += re[k] * re[k] + im[k] * im[k]
	var scale := 1.0 / sqrt(norm)
	for k in dim:
		re[k] *= scale
		im[k] *= scale
